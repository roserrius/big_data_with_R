DATA_DIR  <- file.path("..", "data")
INSTACART_DATA_DIR <- file.path("..", "instacart_data")
FOOTBALL_DATA_DIR <- file.path("..", "football_data")

